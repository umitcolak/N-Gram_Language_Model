#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <random>
#include <ctime>
#include <iterator>
#include <algorithm>
#include <functional>

using namespace std;

struct pair_hash {
    template <class T1, class T2>
    size_t operator() (const pair<T1, T2>& pair) const {
        auto hash1 = hash<T1>{}(pair.first);
        auto hash2 = hash<T2>{}(pair.second);
        return hash1 ^ hash2;
    }
};

string removePunctuation(const string& word) {
    string result;
    copy_if(word.begin(), word.end(), back_inserter(result), [](char c) { return isalpha(c) || isdigit(c); });
    return result;
}

vector<string> tokenize(const string& line) {
    istringstream iss(line);
    string word;
    vector<string> tokens;
    while (iss >> word) {
        transform(word.begin(), word.end(), word.begin(), [](unsigned char c) { return tolower(c); });
        word = removePunctuation(word);
        if (!word.empty()) {
            tokens.push_back(word);
        }
    }
    return tokens;
}

unordered_map<pair<string, string>, vector<pair<string, double>>, pair_hash> loadModel(const string& filename) {
    unordered_map<pair<string, string>, vector<pair<string, double>>, pair_hash> model;
    ifstream file(filename);
    string word1, word2, word3;
    double prob;

    while (file >> word1 >> word2 >> word3 >> prob) {
        model[{word1, word2}].emplace_back(word3, prob);
    }
    file.close();

    cout << "Model loaded with " << model.size() << " entries." << endl;
    return model;
}

string generateText(const unordered_map<pair<string, string>, vector<pair<string, double>>, pair_hash>& model, const pair<string, string>& startWords, int length) {
    string currentWord1 = startWords.first;
    string currentWord2 = startWords.second;
    string result = currentWord1 + " " + currentWord2;
    random_device rd;
    mt19937 gen(rd());

    for (int i = 0; i < length - 2; i++) {
        pair<string, string> currentPair = {currentWord1, currentWord2};
        if (model.find(currentPair) == model.end() || model.at(currentPair).empty()) {
            cout << "No entries for: " << currentPair.first << " " << currentPair.second << endl;
            break; // Stop if no entries for the current pair
        }
        const auto& possibilities = model.at(currentPair);
        
        vector<double> weights;
        for (const auto& p : possibilities) {
            weights.push_back(p.second);
        }
        discrete_distribution<> dist(weights.begin(), weights.end());
        
        int chosenIndex = dist(gen);
        currentWord1 = currentWord2;
        currentWord2 = possibilities[chosenIndex].first;
        result += " " + currentWord2;
    }

    return result;
}

int main() {
    string filename = "C:\\Program Files\\Visual Studio Code Projects\\Language Technology Lab Works\\Lab2\\N-Gram_LanguageModel\\3-gram_trained_model.txt";
    pair<string, string> startWords = {"zato", "bodo"}; // Example start words

    auto model = loadModel(filename);

    if (model.find(startWords) == model.end()) {
        cerr << "Start words not found in model. Please use valid start words." << endl;
        return 1; 
    }

    string generatedText = generateText(model, startWords, 10);
    cout << "Generated Text: " << generatedText << endl;

    return 0;
}
