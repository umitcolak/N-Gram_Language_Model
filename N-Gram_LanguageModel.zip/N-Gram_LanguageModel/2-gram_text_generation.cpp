#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <random>
#include <ctime>
#include <iterator>
#include <algorithm>

using namespace std;

struct pair_hash {
    template <class T1, class T2>
    size_t operator () (const pair<T1, T2>& pair) const {
        auto hash1 = hash<T1>{}(pair.first);
        auto hash2 = hash<T2>{}(pair.second);
        return hash1 ^ hash2;
    }
};

string removePunctuation(const string& word) {
    string result;
    copy_if(word.begin(), word.end(), back_inserter(result),
            [](char c) { return isalpha(c) || isdigit(c); });
    return result;
}

vector<string> tokenize(const string& line) {
    istringstream iss(line);
    string word;
    vector<string> tokens;
    while (iss >> word) {
        transform(word.begin(), word.end(), word.begin(),
                  [](unsigned char c){ return tolower(c); });
        word = removePunctuation(word);
        if (!word.empty()) {
            tokens.push_back(word);
        }
    }
    return tokens;
}

unordered_map<string, vector<pair<string, double>>> loadModel(const string& filename) {
    unordered_map<string, vector<pair<string, double>>> model;
    ifstream file(filename);
    string word1, word2;
    double prob;

    while (file >> word1 >> word2 >> prob) {
        model[word1].push_back(make_pair(word2, prob));
    }
    file.close();

    cout << "Model loaded with " << model.size() << " entries." << endl;

    return model;
}

string generateText(const unordered_map<string, vector<pair<string, double>>>& model, const string& startWord, int length) {
    string currentWord = startWord;
    string result = currentWord;
    random_device rd;
    mt19937 gen(rd());

    for (int i = 0; i < length - 1; i++) {
        if (model.find(currentWord) == model.end() || model.at(currentWord).empty()) {
            cout << "No entries for: " << currentWord << endl;
            break; // Stop if no entries for the current word
        }
        const auto& possibilities = model.at(currentWord);
        
        vector<double> weights;
        for (const auto& p : possibilities) {
            weights.push_back(p.second);
        }
        discrete_distribution<> dist(weights.begin(), weights.end());
        
        int chosenIndex = dist(gen);
        currentWord = possibilities[chosenIndex].first;
        result += " " + currentWord;
    }

    return result;
}
int main() {

    // Loading 2-gram model from file
    string filename = "C:\\Program Files\\Visual Studio Code Projects\\Language Technology Lab Works\\Lab2\\N-Gram_LanguageModel\\2-gram_trained_model.txt";

    
   
    vector<string> startWords = {"prednovoletni", "predstavlja", "nizko", "organizirati", "zois"}; 


    auto model = loadModel(filename);

    for (const auto& startWord : startWords) {
        if (model.find(startWord) != model.end() && !model.at(startWord).empty()) {
            // Generate 5 sentences for each start word
            for (int i = 0; i < 5; ++i) {
                string generatedText = generateText(model, startWord, 10);
                cout << "Generated Text from " << startWord << ": " << generatedText << endl;
            }
        } else {
            cout << "No entries for start word: " << startWord << ", skipping." << endl;
        }
    }

    return 0;
}
