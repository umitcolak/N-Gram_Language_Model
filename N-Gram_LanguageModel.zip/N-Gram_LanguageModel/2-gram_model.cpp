#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cctype>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <filesystem>
#include <cmath>

using namespace std;
namespace fs = filesystem;

struct pair_hash {
    template <class T1, class T2>
    size_t operator () (const pair<T1,T2>& pair) const {
        auto hash1 = hash<T1>{}(pair.first);
        auto hash2 = hash<T2>{}(pair.second);
        return hash1 ^ hash2;
    }
};

string removePunctuation(const string& word) {
    string result;
    copy_if(word.begin(), word.end(), back_inserter(result),
            [](char c) { return isalpha(c) || isdigit(c); });
    return result;
}

vector<string> tokenize(const string& line) {
    istringstream iss(line);
    string word;
    vector<string> tokens;
    while (iss >> word) {
        transform(word.begin(), word.end(), word.begin(),
                  [](unsigned char c){ return tolower(c); });
        word = removePunctuation(word);
        if (!word.empty()) {
            tokens.push_back(word);
        }
    }
    return tokens;
}

unordered_map<pair<string, string>, int, pair_hash> generateBigrams(const vector<string>& tokens, unordered_map<string, int>& wordCount, unordered_map<string, unordered_set<string>>& followers) {
    unordered_map<pair<string, string>, int, pair_hash> bigrams;
    for (size_t i = 0; i < tokens.size() - 1; ++i) {
        pair<string, string> bigram = make_pair(tokens[i], tokens[i+1]);
        bigrams[bigram]++;
        wordCount[tokens[i]]++;
        followers[tokens[i]].insert(tokens[i+1]);
    }
    wordCount[tokens.back()]++;
    return bigrams;
}

double kneserNeyProbability(const string& prev, const string& word, const unordered_map<pair<string, string>, int, pair_hash>& bigrams, const unordered_map<string, int>& wordCount, const unordered_map<string, unordered_set<string>>& followers) {
    const double discount = 0.75;
    auto bigram = make_pair(prev, word);
    double bigramCount = bigrams.count(bigram) ? bigrams.at(bigram) : 0;
    double prevCount = wordCount.at(prev);
    double uniqueFollowers = followers.at(prev).size();
    double continuationCount = followers.count(word) ? followers.at(word).size() : 0;
    double totalWords = wordCount.size();

    double adjustedCount = max(bigramCount - discount, 0.0);
    double lambda = (discount * uniqueFollowers) / prevCount;
    double continuationProbability = continuationCount / totalWords;

    return (adjustedCount / prevCount) + (lambda * continuationProbability);
}

double calculatePerplexity(const vector<string>& words, const unordered_map<pair<string, string>, double, pair_hash>& bigramProbs, const unordered_map<string, int>& wordCount) {
    double logProb = 0.0;
    int count = 0;

    for (size_t i = 0; i < words.size() - 1; ++i) {
        string w1 = words[i];
        string w2 = words[i + 1];
        pair<string, string> bigram = make_pair(w1, w2);

        try {
            if (wordCount.at(w1) > 0) { 
                if (bigramProbs.count(bigram)) {
                    double prob = bigramProbs.at(bigram);
                    logProb += log(prob);
                } else {
                    // Smoothing for unseen bigrams
                    logProb += log(1.0 / (wordCount.at(w1) + wordCount.size()));
                }
                count++;
            }
        } catch (const std::out_of_range& e) {

            logProb += log(1.0 / wordCount.size());
            count++;
        }
    }

    double perplexity = exp(-logProb / count);
    return perplexity;
}

int main() {
    string directoryPath = "C:\\Program Files\\Visual Studio Code Projects\\Language Technology Lab Works\\Lab2\\N-Gram_LanguageModel\\Training Corpus";
    string outputPath = "C:\\Program Files\\Visual Studio Code Projects\\Language Technology Lab Works\\Lab2\\N-Gram_LanguageModel\\2-gram_trained_model.txt";
    string testPath = "C:\\Program Files\\Visual Studio Code Projects\\Language Technology Lab Works\\Lab2\\N-Gram_LanguageModel\\Test Corpus\\kas-8386000.text.txt";
    unordered_map<string, int> wordCount;
    unordered_map<string, unordered_set<string>> followers;
    unordered_map<pair<string, string>, int, pair_hash> bigrams;

    for (const auto& entry : fs::directory_iterator(directoryPath)) {
        if (entry.path().extension() == ".txt") {
            ifstream file(entry.path());
            if (!file) {
                cerr << "Unable to open " << entry.path() << " for reading." << endl;
                continue;
            }
            string line;
            vector<string> tokens;
            while (getline(file, line)) {
                vector<string> lineTokens = tokenize(line);
                tokens.insert(tokens.end(), lineTokens.begin(), lineTokens.end());
            }
            file.close();
            auto localBigrams = generateBigrams(tokens, wordCount, followers);
            for (const auto& b : localBigrams) {
                bigrams[b.first] += b.second;
            }
        }
    }

    ofstream modelFile(outputPath);
    if (!modelFile) {
        cerr << "Unable to open output file." << endl;
        return 1;
    }

    unordered_map<pair<string, string>, double, pair_hash> bigramProbs;

    for (const auto& bigram : bigrams) {
        double prob = kneserNeyProbability(bigram.first.first, bigram.first.second, bigrams, wordCount, followers);
        bigramProbs[bigram.first] = prob;
        modelFile << bigram.first.first << " " << bigram.first.second << " " << prob << endl;
    }
    modelFile.close();

    // Load test data and calculate perplexity
    ifstream testFile(testPath);
    if (!testFile) {
        cerr << "Unable to open test data file." << endl;
        return 1;
    }

    string line;
    vector<string> testTokens;
    while (getline(testFile, line)) {
        vector<string> lineTokens = tokenize(line);
        testTokens.insert(testTokens.end(), lineTokens.begin(), lineTokens.end());
    }
    testFile.close();

    double perplexity = calculatePerplexity(testTokens, bigramProbs, wordCount);
    cout << "Perplexity of the test set: " << perplexity << endl;

    return 0;
}
