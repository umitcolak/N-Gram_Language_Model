#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cctype>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <filesystem>
#include <cmath>

using namespace std;
namespace fs = filesystem;

struct triple_hash {
    template <class T1, class T2, class T3>
    size_t operator () (const tuple<T1,T2,T3>& tuple) const {
        auto hash1 = hash<T1>{}(get<0>(tuple));
        auto hash2 = hash<T2>{}(get<1>(tuple));
        auto hash3 = hash<T3>{}(get<2>(tuple));
        return hash1 ^ hash2 ^ hash3; 
    }
};

string removePunctuation(const string& word) {
    string result;
    copy_if(word.begin(), word.end(), back_inserter(result),
            [](char c) { return isalpha(c) || isdigit(c); });
    return result;
}

vector<string> tokenize(const string& line) {
    istringstream iss(line);
    string word;
    vector<string> tokens;
    while (iss >> word) {
        transform(word.begin(), word.end(), word.begin(),
                  [](unsigned char c){ return tolower(c); });
        word = removePunctuation(word);
        if (!word.empty()) {
            tokens.push_back(word);
        }
    }
    return tokens;
}

unordered_map<tuple<string, string, string>, int, triple_hash> generateTrigrams(const vector<string>& tokens, unordered_map<string, int>& wordCount, unordered_map<string, unordered_set<string>>& followers) {
    unordered_map<tuple<string, string, string>, int, triple_hash> trigrams;
    for (size_t i = 0; i < tokens.size() - 2; ++i) {
        tuple<string, string, string> trigram = make_tuple(tokens[i], tokens[i+1], tokens[i+2]);
        trigrams[trigram]++;
        wordCount[tokens[i]]++;
        followers[tokens[i]].insert(tokens[i+1]); // Only records the immediate follower
    }
    wordCount[tokens.back()]++;
    return trigrams;
}

double kneserNeyProbability(const string& first, const string& second, const string& third, 
                            const unordered_map<tuple<string, string, string>, int, triple_hash>& trigrams, 
                            const unordered_map<string, int>& wordCount, 
                            const unordered_map<string, unordered_set<string>>& followers) {
    const double discount = 0.75;
    auto trigram = make_tuple(first, second, third);
    
    double trigramCount = trigrams.find(trigram) != trigrams.end() ? trigrams.at(trigram) : 0;
    double prevCount = wordCount.find(second) != wordCount.end() ? wordCount.at(second) : 0;
    double uniqueFollowers = followers.find(second) != followers.end() ? followers.at(second).size() : 0;
    double continuationCount = followers.find(third) != followers.end() ? followers.at(third).size() : 0;
    
    double totalWords = wordCount.size();
    double adjustedCount = max(trigramCount - discount, 0.0);
    double lambda = prevCount > 0 ? (discount * uniqueFollowers) / prevCount : 0;
    double continuationProbability = totalWords > 0 ? continuationCount / totalWords : 0;
    
    return adjustedCount / (prevCount > 0 ? prevCount : 1) + lambda * continuationProbability;
}


double calculatePerplexity(const vector<string>& words, 
                           const unordered_map<tuple<string, string, string>, double, triple_hash>& trigramProbs, 
                           const unordered_map<string, int>& wordCount) {
    double logProb = 0.0;
    int count = 0;
    
    for (size_t i = 0; i < words.size() - 2; ++i) {
        string w1 = words[i];
        string w2 = words[i + 1];
        string w3 = words[i + 2];
        tuple<string, string, string> trigram = make_tuple(w1, w2, w3);
        
        if (trigramProbs.find(trigram) != trigramProbs.end() && wordCount.find(w1) != wordCount.end()) {
            double prob = trigramProbs.at(trigram);
            logProb += log(prob);
        } else {
            logProb += log(1.0 / (wordCount.find(w1) != wordCount.end() ? wordCount.at(w1) + wordCount.size() : 1));
        }
        count++;
    }
    
    double perplexity = exp(-logProb / count);
    return perplexity;
}



int main() {
    string directoryPath = "C:\\Program Files\\Visual Studio Code Projects\\Language Technology Lab Works\\Lab2\\N-Gram_LanguageModel\\Training Corpus";
    string outputPath = "C:\\Program Files\\Visual Studio Code Projects\\Language Technology Lab Works\\Lab2\\N-Gram_LanguageModel\\3-gram_trained_model.txt";
    string testPath = "C:\\Program Files\\Visual Studio Code Projects\\Language Technology Lab Works\\Lab2\\N-Gram_LanguageModel\\Test Corpus\\kas-8386000.text.txt";
    unordered_map<string, int> wordCount;
    unordered_map<string, unordered_set<string>> followers;
    unordered_map<tuple<string, string, string>, int, triple_hash> trigrams;
    unordered_map<tuple<string, string, string>, double, triple_hash> trigramProbs;

    for (const auto& entry : fs::directory_iterator(directoryPath)) {  
        if (entry.path().extension() == ".txt") {
            ifstream file(entry.path());
            if (!file) {
                cerr << "Unable to open " << entry.path() << " for reading." << endl;
                continue;
            }
            string line;
            vector<string> tokens;
            while (getline(file, line)) {
                vector<string> lineTokens = tokenize(line);
                tokens.insert(tokens.end(), lineTokens.begin(), lineTokens.end());
            }
            file.close();
            auto localTrigrams = generateTrigrams(tokens, wordCount, followers);
            for (const auto& t : localTrigrams) {
                trigrams[t.first] += t.second;
            }
        }
    }

    ofstream modelFile(outputPath);
    if (!modelFile) {
        cerr << "Unable to open output file." << endl;
        return 1;
    }
    for (const auto& trigram : trigrams) {
        double prob = kneserNeyProbability(get<0>(trigram.first), get<1>(trigram.first), get<2>(trigram.first), trigrams, wordCount, followers);
        trigramProbs[trigram.first] = prob; // Store probabilities in the map
        modelFile << get<0>(trigram.first) << " " << get<1>(trigram.first) << " " << get<2>(trigram.first) << " " << prob << endl;
    }
    modelFile.close();

    ifstream testFile(testPath);
    vector<string> testTokens;
    if (testFile) {
        string line;
        while (getline(testFile, line)) {
            vector<string> lineTokens = tokenize(line);
            testTokens.insert(testTokens.end(), lineTokens.begin(), lineTokens.end());
        }
        testFile.close();
        double perplexity = calculatePerplexity(testTokens, trigramProbs, wordCount);
        cout << "Perplexity of the test set: " << perplexity << endl;
    } else {
        cerr << "Unable to open test data file." << endl;
        return 1;
    }

    return 0;
}
